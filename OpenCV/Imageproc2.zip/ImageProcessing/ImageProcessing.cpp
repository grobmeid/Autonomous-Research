#include "opencv2/highgui/highgui.hpp"
#include "opencv2/imgproc/imgproc.hpp"
#include "opencv2/opencv.hpp"
// This include is for blob detection...
#include "opencv2/features2d.hpp"
#include <iostream>

using namespace cv;
using namespace std;

void help();

int main(int argc, char** argv)
{
    const char* filename = argc >= 2 ? argv[1] : "CameraCenter.png";

    // Making src read in the image with color
        // With more time, this would read in multiple images 
        // Real-Time from Blender Suite. But I decided one image was fine.  
    Mat src = imread("CameraCenter.png", CV_LOAD_IMAGE_COLOR);
    // Test, keeping a clone of the original. 
    Mat srcDirectFile = src.clone();

    // If the source is empty, quit the program. 
    if (src.empty())
    {
        help();
        cout << "can not open " << filename << endl;
        return -1;
    }

    // Declaring my dst and cdst
    Mat dst, cdst;
    // This is where edge detection begins.
    Canny(src, dst, 50, 200, 3);
    cvtColor(dst, cdst, CV_GRAY2BGR);


    //Standard Hough Line Transform
#if 0
    vector<Vec2f> lines;

    HoughLines(dst, lines, 1, CV_PI / 150, 100, 0, 0);

    for (size_t i = 0; i < lines.size(); i++)
    {
        float rho = lines[i][0], theta = lines[i][1];
        Point pt1, pt2;
        double a = cos(theta), b = sin(theta);
        double x0 = a * rho, y0 = b * rho;
        pt1.x = cvRound(x0 + 1000 * (-b));
        pt1.y = cvRound(y0 + 1000 * (a));
        pt2.x = cvRound(x0 - 1000 * (-b));
        pt2.y = cvRound(y0 - 1000 * (a));
        line(cdst, pt1, pt2, Scalar(0, 0, 0), 3, CV_AA);
        //   line(src, pt1, pt2, const Scalar(0, 255, 0), 2, lineType = 8, shift = 0);
    }
#else
    vector<Vec4i> lines;
    HoughLinesP(dst, lines, 1, CV_PI / 180, 50, 50, 10);
    for (size_t i = 0; i < lines.size(); i++)
    {
        Vec4i l = lines[i];
        line(cdst, Point(l[0], l[1]), Point(l[2], l[3]), Scalar(0, 0, 0), 3, CV_AA);
        //   line(cdst, pt1, pt2, const Scalar(0, 255, 0), 2, lineType = 8, shift = 0);
    }
#endif

   // The following code is from OpenCV devs
    Mat canny_output;
    Mat thr, gray;
    Mat srctwo = imread("CameraCenter.png", IMREAD_GRAYSCALE);
    threshold(gray, thr, 100, 255, THRESH_BINARY);

    vector<vector<Point> > contours;
    vector<Vec4i> hierarchy;
    Canny(gray, canny_output, 50, 150, 3);
    findContours(canny_output, contours, hierarchy, RETR_TREE, CHAIN_APPROX_SIMPLE, Point(0, 0));

    vector<Moments> mu(contours.size());
        for (int i = 0; i < contours.size(); i++) { 
            mu[i] = moments(contours[i], false); 
        }

    vector<Point2f> mc(contours.size());
    for (int i = 0; i < contours.size(); i++)
    {
        mc[i] = Point2f(mu[i].m10 / mu[i].m00, mu[i].m01 / mu[i].m00);
    }

    for (int i = 0; i < contours.size(); i++) {
        Scalar color = Scalar(167, 151, 0);
        drawContours(srctwo, contours, i, color, 2, 8, hierarchy, 0, Point());
        circle(srctwo, mc[i], 4, color, -1, 8, 0);
    }

    Scalar lowerb = Scalar(0, 0, 0);
    Scalar upperb = Scalar(0, 0, 0);
    Mat mask;

    //Searching for pixels in lower & upper bound regions. 
    inRange(cdst, lowerb, upperb, mask);

    imshow("source", src);
    imshow("detected lines", cdst);
    //Thought this would give me an outline of the object I am looking for, guess not. 
    imshow("Contours", srctwo);
    //This imshow shows too much noise...doesn't work for this application. 
    imshow("mask", mask);
    
    /*
    cvtColor(src, gray, COLOR_BGR2GRAY);
    threshold(gray, thr, 100, 255, THRESH_BINARY);
    Moments m = moments(thr, true);
    Point p(m.m10 / m.m00, m.m01 / m.m00);
    cout << Mat(p) << endl;
    circle(src, p, 5, Scalar(255, 0, 0), -1);
    imshow("Image with center", src);
    */
    /*These are for arrow designations, which what the car should turn*/
    /*
    Mat left = imread("arrowLeft.png", CV_LOAD_IMAGE_COLOR);
    Mat right = imread("arrowRight.png", CV_LOAD_IMAGE_COLOR);
    Mat both = imread("arrowBoth.png", CV_LOAD_IMAGE_COLOR);
    */
    //For tracking objects in red, for test purposes

    waitKey();
    return 0;
}

void help() {
    cout << "\nThis program demonstrates line finding with the Hough transform.\n"
        "Usage:\n"
        "./houghlines <image_name>, Default is pic1.jpg\n" << endl;
}